"use client";

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { ProductVariantInput } from "@/modules/products/validation/schemas";

interface OptionDraft {
  name: string;
  values: string; // comma-separated while editing
}

export function VariantEditor({
  variants,
  onChange,
}: {
  variants: ProductVariantInput[];
  onChange: (variants: ProductVariantInput[]) => void;
}) {
  const [options, setOptions] = useState<OptionDraft[]>(() => deriveOptionsFromVariants(variants));

  function addOption() {
    setOptions((prev) => [...prev, { name: "", values: "" }]);
  }

  function removeOption(index: number) {
    setOptions((prev) => prev.filter((_, i) => i !== index));
  }

  function updateOption(index: number, patch: Partial<OptionDraft>) {
    setOptions((prev) => prev.map((o, i) => (i === index ? { ...o, ...patch } : o)));
  }

  function generateVariants() {
    const cleanOptions = options
      .map((o) => ({
        name: o.name.trim(),
        values: Array.from(
          new Set(
            o.values
              .split(",")
              .map((v) => v.trim())
              .filter(Boolean)
          )
        ),
      }))
      .filter((o) => o.name && o.values.length > 0);

    if (cleanOptions.length === 0) {
      onChange([]);
      return;
    }

    const combos = cleanOptions.reduce<Record<string, string>[]>(
      (acc, option) => acc.flatMap((combo) => option.values.map((value) => ({ ...combo, [option.name]: value }))),
      [{}]
    );

    const existingByName = new Map(variants.map((v) => [v.name, v]));

    const next: ProductVariantInput[] = combos.map((combo) => {
      const name = Object.values(combo).join(" / ");
      return (
        existingByName.get(name) ?? {
          name,
          options: combo,
          sku: "",
          price: null,
          compareAtPrice: null,
          inventoryQuantity: 0,
          imageUrl: "",
        }
      );
    });

    onChange(next);
  }

  function updateVariant(index: number, patch: Partial<ProductVariantInput>) {
    onChange(variants.map((v, i) => (i === index ? { ...v, ...patch } : v)));
  }

  function removeVariant(index: number) {
    onChange(variants.filter((_, i) => i !== index));
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3">
        {options.map((option, index) => (
          <div key={index} className="flex flex-wrap items-end gap-2">
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">Option name</Label>
              <Input
                placeholder="e.g. Color"
                value={option.name}
                onChange={(e) => updateOption(index, { name: e.target.value })}
                className="w-40"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">Values (comma-separated)</Label>
              <Input
                placeholder="e.g. Black, White, Red"
                value={option.values}
                onChange={(e) => updateOption(index, { values: e.target.value })}
                className="w-64"
              />
            </div>
            <Button type="button" variant="ghost" size="icon" onClick={() => removeOption(index)}>
              <Trash2 className="size-4" />
            </Button>
          </div>
        ))}
        <div className="flex gap-2">
          <Button type="button" variant="outline" size="sm" onClick={addOption}>
            <Plus className="size-4" /> Add option
          </Button>
          {options.length > 0 && (
            <Button type="button" variant="secondary" size="sm" onClick={generateVariants}>
              Generate variants
            </Button>
          )}
        </div>
      </div>

      {variants.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Variant</TableHead>
              <TableHead>SKU</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Inventory</TableHead>
              <TableHead className="w-9" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {variants.map((variant, index) => (
              <TableRow key={variant.id ?? variant.name}>
                <TableCell className="font-medium">{variant.name}</TableCell>
                <TableCell>
                  <Input
                    value={variant.sku ?? ""}
                    onChange={(e) => updateVariant(index, { sku: e.target.value })}
                    className="h-8 w-28"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="Same as product"
                    value={variant.price ?? ""}
                    onChange={(e) =>
                      updateVariant(index, { price: e.target.value === "" ? null : Number(e.target.value) })
                    }
                    className="h-8 w-32"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    value={variant.inventoryQuantity}
                    onChange={(e) => updateVariant(index, { inventoryQuantity: Number(e.target.value) })}
                    className="h-8 w-20"
                  />
                </TableCell>
                <TableCell>
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeVariant(index)}>
                    <Trash2 className="size-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}

function deriveOptionsFromVariants(variants: ProductVariantInput[]): OptionDraft[] {
  const map = new Map<string, Set<string>>();
  for (const variant of variants) {
    for (const [key, value] of Object.entries(variant.options ?? {})) {
      if (!map.has(key)) map.set(key, new Set());
      map.get(key)!.add(value);
    }
  }
  return Array.from(map.entries()).map(([name, values]) => ({
    name,
    values: Array.from(values).join(", "),
  }));
}
